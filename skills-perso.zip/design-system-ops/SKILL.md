---
name: design-system-ops
description: >-
  Use this for design system ops work: auditing tokens, Figma variables,
  components, naming, themes, accessibility or system health; documenting
  tokens, components or patterns; deprecations, release notes and governance. It
  routes to the right recipe in the Design System Ops library
  (murphytrueman/design-system-ops, MIT).
---
# Design System Ops (index)

This is the Design System Ops library by Murphy Trueman, under the MIT license. Source: https://github.com/murphytrueman/design-system-ops, commit f167898 of 2026-09-24.

A local copy of the whole repo is kept on the box at `/home/box/skill-sources/design-system-ops`.

## How to use it
1. Use the list below to pick the sub-skill that fits the request.
2. Read it in full with Read: `/home/box/skill-sources/design-system-ops/skills/<name>/SKILL.md`.
3. Follow it. When it cites a note in `knowledge-notes/` or a command in `commands/`, read that file from the same repo root. Multi-step agents live in `skills/*-agent.md`.
4. Adapt it to the tools you actually have:
   - For Figma, use the connected Figma connector and load the `figma-use` skill before any `use_figma` call.
   - Ignore instructions specific to Claude Code, Cowork or Figma Console MCP.
   - Never write to a file without the user's explicit consent.
5. Answer in the user's language. Never invent a value: report only what you actually read.
6. To refresh the copy, run `git -C /home/box/skill-sources/design-system-ops pull`. If the folder is missing, clone it again from the URL above.

## Sub-skills (skills/<name>/SKILL.md)
**Audits**
- token-audit: how tokens are defined (tiers, naming, alias chains, raw values, orphans, DTCG readiness).
- figma-variable-audit: Figma variable collections (tier mapping, naming, alias chains, modes, orphans).
- component-audit: component library inventory, usage, duplication, complexity, coverage gaps.
- naming-audit: component and pattern names, with rename suggestions.
- theme-audit: theme and mode parity, contrast per theme.
- accessibility-per-component: WCAG 2.2 AA audit of one component.
- component-api-validator: prop APIs across a library.
- token-compliance: hardcoded values in consuming code.
- drift-detection: where consuming code drifted from the system.
- design-to-code-check: design spec vs code gaps.
- docs-coverage: undocumented or stale components.
- system-health: holistic health check and maturity stage.
- adoption-report: coverage, reach and adoption.
- schema-validator: token files against DTCG, Style Dictionary or Tokens Studio.

**Documentation**
- token-documentation: token reference docs.
- usage-guidelines: usage guidelines for one component.
- pattern-documentation: multi-component patterns.
- component-decision-tree: "choosing between" pages.
- ai-component-description: Figma component descriptions readable by LLMs.
- onboarding: onboarding guide for a new designer or engineer.
- agent-instructions: AGENTS.md for coding agents.
- metadata-schema-generator: per-component JSON metadata.
- codebase-index: .ai/index files.

**Governance and changes**
- decision-record: ADR for a design system choice.
- deprecation-process: end-to-end deprecation plan.
- change-communication: release notes, migration guide, announcement.
- version-bump-advisor: semver bump and CHANGELOG entry.
- release-retrospective: post-release review.
- contribution-workflow: contribution process.
- governance-encoder: rules turned into lint and CODEOWNERS config.
- codemod-generator: migration codemods.
- cicd-integration: CI checks for the design system.
- backlog-generator: tickets from audit findings.

**Communication**
- stakeholder-brief: one-page business brief.
- system-pitch: investment pitch.
- visual-report: HTML dashboard, charts or Mermaid from audit output.

**Multi-step agents (skills/*-agent.md)**
- full-system-diagnostic-agent, token-migration-agent, governance-review-agent, component-to-release-agent.
