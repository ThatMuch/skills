---
name: figma-draw
description: >-
  Create and optimize vector graphics for Figma Draw. Use when generating SVG
  illustrations, icons, logos, or hand-drawn style graphics for import into
  Figma, or when needing guidance on Figma Draw tools like brushes, dynamic
  strokes, and vector editing.
---
# Figma Draw — Vector Graphics for Figma

Generate production-ready SVG vector graphics optimized for import into Figma and refinement with Figma Draw tools. Use for illustrations, icons, logos, organic hand-drawn effects, or any vector work destined for Figma.

## Core Workflow

1. Clarify style, subject, colors, dimensions, and intended use (icon, illustration, logo, texture).
2. Generate clean SVG code or file. Prefer simple `<path>` elements with absolute coordinates. Minimize groups, filters, and nested complexity that Figma may flatten or expand poorly.
3. Save the result as a `.svg` file in the artifacts directory.
4. Deliver the file and clear import instructions: drag-and-drop into a Figma Design file, or paste SVG code. Then switch to Draw mode for further editing.
5. Suggest specific Figma Draw enhancements (dynamic strokes, custom brushes, noise, variable width, text on path) based on the style requested.

## SVG Generation Guidelines

- Use valid, minimal SVG. Set `viewBox` for scalability.
- Prefer `path` with `d` attribute for custom shapes. Use `M`, `L`, `C`, `Q`, `A`, `Z` commands.
- Set fills and strokes via attributes (`fill`, `stroke`, `stroke-width`) rather than complex CSS when possible.
- For organic/hand-drawn feel: create slightly irregular paths or note that dynamic strokes / brushes should be applied after import.
- Avoid excessive precision or thousands of points; simplify for editability.
- Gradients and patterns are supported but may need manual adjustment in Figma.
- Example minimal structure:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <path d="M 10 150 L 100 20 L 190 150 Z" fill="#4A90E2" stroke="#2C3E50" stroke-width="2"/>
</svg>
```

## Figma Draw Tools Quick Reference

| Tool / Feature | Purpose | Key Tips |
|---|---|---|
| Pencil | Freehand sketches | Auto-places vector points; good for rough ideas |
| Brush | Textured, organic strokes | Stretch or scatter custom brushes; create from any vector |
| Pen | Precise vector paths | Click to place points; drag for curves |
| Dynamic strokes | Organic wiggle & variation | Adjust frequency, size jitter, angular jitter |
| Variable width | Thickness along path | Set width points for calligraphic feel |
| Pattern fill / Noise / Texture | Add grain or patterns | Apply to fills or strokes for analog look |
| Progressive blur | Depth | Layer or background blur |
| Text on path | Curved text | Mold text to any vector path |
| Shape builder / Boolean | Combine shapes | Union, subtract, intersect for complex forms |
| Lasso / Multi-node edit | Selection | Freehand select; edit multiple nodes at once |

Enter Draw mode via the toolbar toggle in Figma Design. Switch back to Design mode for full layout tools.

## Import & Edit Tips

- After importing SVG, ungroup layers if Figma creates groups.
- Double-click a vector or press Enter to enter vector edit mode and adjust anchors/handles.
- For hand-drawn results: import clean paths, then apply Brush or Dynamic strokes.
- Use the upgraded boolean operations and outline stroke for cleaner combinations.
- Custom brushes: select a vector → right-click → Create brush (Stretch or Scatter).

## Common Issues

| Problem | Fix |
|---|---|
| SVG imports as many tiny layers | Simplify paths before export; use fewer compound paths |
| Gradients look wrong | Recreate or adjust gradient stops in Figma |
| Stroke styles lost | Re-apply stroke properties or dynamic settings after import |
| Too precise / rigid | Apply Dynamic strokes or variable width in Draw mode |
| File too large | Reduce path points; avoid embedded rasters |

When the user wants pure raster output instead of vectors, note that Figma Draw produces editable vectors by default.
