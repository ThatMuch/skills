# Changelog

## 2026-10-30
- Initial skill creation
- Added knowledge graph structure with INDEX.md
- Populated references for components, design systems, UX concepts, methods, and sources
- Based on synthesis of Component Gallery, NN/g, ANODA, and foundational books
