---
name: ux-ui-glossary
description: >-
  Glossary of terms bridging UX design, UI design, and front-end development.
  Use when looking up UI components, design system concepts, accessibility
  terms, shared vocabulary between designers and developers, or distinctions
  like Modal vs Dialog.
---
# UX/UI Glossary — Bridge Terms for Design and Front-End

Provides concise definitions, synonyms, and common distinctions for technical terms that cross UX design, UI design, and front-end development. Inspired by Component Gallery and ANODA UX Glossary structure.

Use this skill to align vocabulary, clarify naming in design systems, explain components to developers, or look up patterns with accessibility implications.

## How to Use

1. Identify the category of the term (component, design system concept, UX principle, method).
2. Read the relevant reference file from this skill's `references/` folder (open it with Read).
3. Report definition + synonyms + any key distinctions or implementation notes.
4. Cite sources when relevant for further reading.

## Knowledge Graph

Start at `references/INDEX.md` for the full map of terms and connections.

### Categories
- `references/components.md`: UI elements and patterns (Accordion, Toast, Drawer, etc.)
- `references/design-systems.md`: tokens, Atomic Design, component libraries, states, ARIA
- `references/ux-concepts.md`: principles that affect implementation (Affordance, Progressive disclosure)
- `references/methods.md`: research and design methods
- `references/sources.md`: recommended glossaries and books

Evals are in `evals/`, history in `CHANGELOG.md`. This is a standalone knowledge skill.
