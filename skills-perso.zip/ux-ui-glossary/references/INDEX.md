---
description: "Knowledge graph index for ux-ui-glossary. Start here to navigate terms bridging UX, UI, and front-end."
---

# UX/UI Glossary Knowledge Graph

## Core Categories

- [[components]] — Catalog of UI components and patterns with definitions, synonyms, and design system examples. Ideal for naming alignment.
- [[design-systems]] — Concepts for building and implementing design systems: tokens, Atomic Design, props, variants, elevation.
- [[ux-concepts]] — Foundational UX principles that directly impact front-end implementation and accessibility.
- [[methods]] — Common research and design methods and artefacts shared across disciplines.
- [[sources]] — Primary references including Component Gallery, NN/g glossaries, books, and design system docs.

## Quick Lookup Tips

- For component names and synonyms → start with [[components]]
- For "what is a design token" or Atomic Design → [[design-systems]]
- For Affordance, Signifier, Progressive disclosure → [[ux-concepts]]
- For distinctions (Modal vs Dialog, Toast vs Snackbar) → see notes in the relevant files
