---
description: "UI components and interface patterns with short definitions, synonyms, and notes on usage or accessibility. Modeled after Component Gallery and NN/g UI Elements Glossary."
connections: [design-systems, ux-concepts, sources]
---

# UI Components & Patterns

Terms style Component Gallery / Nielsen Norman Group. Each entry: definition + common synonyms + notes.

| Term | Definition | Synonyms | Notes / Distinctions |
|------|------------|----------|----------------------|
| Accordion | A vertically stacked set of interactive headings that reveal or hide content sections. | Collapse, Disclosure, Expander, Collapsible | Progressive disclosure pattern. Ensure keyboard and ARIA support. |
| Alert | A message that informs the user of a status or action result, often temporary or dismissible. | Banner, Notification, Callout | Distinguish from Toast (usually more persistent or critical). |
| Avatar | A visual representation of a user or entity, often a photo or initials. | Profile picture, User icon | Common in lists, comments, headers. |
| Badge | A small label or indicator for status, count, or category. | Tag, Chip, Pill, Label | Often used for notifications count or status. |
| Breadcrumbs | A navigational aid showing the user's location in a hierarchy. | Path, Navigation trail | Helps with information architecture and wayfinding. |
| Button | An interactive control that triggers an action. | CTA, Action | Includes primary, secondary, tertiary, icon-only variants. |
| Button group | A set of related buttons presented together. | Segmented control, Toggle group | For mutually exclusive or multi-select actions. |
| Card | A contained unit of content and actions, often with a distinct visual boundary. | Tile, Panel | Elevation and shadow often used for hierarchy. |
| Carousel | A horizontally scrolling set of items, often with navigation controls. | Slider, Slideshow, Rotator | Accessibility challenges; provide alternatives. |
| Checkbox | A control for selecting one or more options from a set. | Check box, Tick box | Multi-select. Contrast with Radio (single) and Switch (binary on/off). |
| Combobox | A text input combined with a dropdown list for selection or filtering. | Autocomplete, Typeahead, Select with search | ARIA role important for accessibility. |
| Datepicker | A control for selecting a date, often via calendar popup. | Date picker, Calendar input | Complex keyboard and screen reader support needed. |
| Drawer | A panel that slides in from the edge of the screen. | Tray, Flyout, Side sheet, Sidebar | Common for navigation or filters. Distinguish from Modal (overlay). |
| Dropdown | A control that reveals a list of options. | Select, Menu, Picker | Includes native select and custom implementations. |
| Empty state | A designed view shown when there is no content or data. | Zero state, Blank state | Opportunity for guidance or call-to-action. |
| Form | A collection of inputs for collecting user data. | — | Includes validation, error states, progressive disclosure. |
| Modal / Dialog | A window that overlays the main content and requires interaction. | Dialog, Popup, Overlay | Modal blocks interaction with background; Dialog may be less strict. Common distinction debated. |
| Pagination | Controls for navigating between pages of content. | Pager | Alternative to infinite scroll. |
| Popover | A floating panel that appears on interaction, containing additional content or actions. | Tooltip (if simple), Flyout | More complex than Tooltip. |
| Progress bar / indicator | Visual representation of task completion or loading. | Progress indicator, Loading bar | Determinate vs indeterminate. |
| Radio | A control for selecting exactly one option from a set. | Radio button, Option button | Single-select group. |
| Skeleton | A placeholder UI that mimics the shape of content while loading. | Skeleton screen, Content placeholder | Improves perceived performance. |
| Slider | A control for selecting a value from a continuous or stepped range. | Range input, Seek bar | Includes dual-handle for ranges. |
| Spinner | An indeterminate loading indicator. | Loader, Activity indicator | Use for short waits; prefer Skeleton for longer. |
| Tabs | A set of selectable sections that show different content. | Tab list, Tabbed interface | Ensure keyboard navigation and ARIA. |
| Toast / Snackbar | A brief, non-blocking message that appears temporarily. | Snackbar, Notification toast | Toast often top/center; Snackbar bottom. Both non-modal. |
| Toggle / Switch | A control for binary on/off state. | Switch, Toggle button | Immediate effect preferred over form submit. |
| Tooltip | A small popup that explains an element on hover or focus. | Hint, Info tip | Keep short; ensure keyboard accessibility. |
| Tree view | A hierarchical list that can expand/collapse nodes. | Tree, Outline | Common in file browsers, navigation. |

**Common Distinctions**
- Modal vs Dialog: Modal typically traps focus and blocks background; Dialog is broader term.
- Toast vs Snackbar: Often synonymous; Material Design uses Snackbar for bottom temporary messages.
- Drawer vs Side sheet: Drawer often temporary overlay; Side sheet more persistent panel.
- Checkbox vs Switch vs Radio: Checkbox multi, Switch binary immediate, Radio single exclusive.

See [[design-systems]] for how these are implemented as components with props/variants/states. See [[sources]] for Component Gallery and NN/g.