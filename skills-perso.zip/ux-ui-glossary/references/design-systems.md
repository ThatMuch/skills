---
description: "Design system concepts, Atomic Design, design tokens, component implementation details that bridge design and front-end code."
connections: [components, ux-concepts, sources]
---

# Design Systems & Front-End Implementation

Concepts that form the bridge between design tools and code.

## Key Terms

| Term | Definition | Notes |
|------|------------|-------|
| Design system | A collection of reusable components, patterns, guidelines, and tokens that ensure consistency across products. | Encompasses more than just a component library. |
| Component library | A set of coded, reusable UI components. | Often the implementation of a design system. |
| Pattern library | A collection of interaction patterns and solutions to common UX problems. | Can exist independently of coded components. |
| Design token | Named values (color, spacing, typography, etc.) that form the single source of truth. | Hierarchy: Primitive → Semantic → Component tokens. |
| Atomic Design | Methodology by Brad Frost: Atoms → Molecules → Organisms → Templates → Pages. | Helps structure component hierarchy. |
| Component | A reusable, self-contained piece of UI with defined props, states, and behavior. | In code: props, slots, events, variants, states. |
| Props / API | The interface a component exposes to control its appearance and behavior. | Designers specify; developers implement. |
| Variants | Predefined alternative appearances or behaviors of a component (e.g., primary/secondary button). | Often driven by props. |
| States | Different appearances based on interaction or data: default, hover, focus, active, disabled, loading, error, empty. | Critical for accessibility and feedback. |
| Elevation | Visual hierarchy via shadows, z-index, or layering to indicate importance or depth. | Common in Material Design. |
| Breakpoint | A specific viewport width at which layout changes. | Part of responsive design. |
| Responsive design | Layout that adapts fluidly to different screen sizes. | Contrast with Adaptive (discrete layouts). |
| ARIA | Accessible Rich Internet Applications — roles, states, and properties for assistive technologies. | Essential for custom components. |
| Focus management | Controlling keyboard focus, especially in modals, drawers, and dynamic content. | Key for accessibility. |
| Touch target | Minimum size of interactive elements for reliable touch interaction (typically 44×44px). | Accessibility and usability. |

## Design Token Hierarchy (common pattern)
- **Primitive / Base**: Raw values (e.g., `blue-500`, `spacing-4`)
- **Semantic**: Meaning-based (e.g., `color-primary`, `space-md`)
- **Component**: Specific usage (e.g., `button-background`, `card-padding`)

## Atomic Design Levels
1. **Atoms**: Basic elements (button, input, label)
2. **Molecules**: Simple groups (search form, card header)
3. **Organisms**: Complex sections (header, product grid)
4. **Templates**: Page layouts without real content
5. **Pages**: Specific instances with real content

See [[components]] for specific component examples. See [[ux-concepts]] for principles that guide token and state decisions. See [[sources]] for Brad Frost and design system references.