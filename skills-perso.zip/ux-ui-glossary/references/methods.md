---
description: "Common UX/UI methods, artefacts, and research techniques shared across design and development teams."
connections: [ux-concepts, sources]
---

# Methods & Artefacts

| Term | Definition | Notes |
|------|------------|-------|
| Usability testing | Observing real users attempting tasks with a product. | Reveals issues not found in expert review. |
| Heuristic evaluation | Expert review against established usability principles (e.g., Nielsen's 10). | Quick, cost-effective. |
| Card sorting | Method for understanding how users group and label information. | Open or closed; informs IA. |
| Persona | Archetypal user representation based on research. | Invented/popularized by Alan Cooper. |
| Journey map | Visualization of a user's end-to-end experience with a product or service. | Includes emotions, pain points, opportunities. |
| A/B testing | Comparing two variants to measure which performs better. | Quantitative; requires sufficient traffic. |
| Design sprint | Structured 5-day process for solving problems and testing ideas (Google Ventures). | Includes prototype and user testing. |
| DesignOps | Operationalizing design processes, tools, and team practices. | Parallel to DevOps. |
| Interaction Design | Designing the behavior and interaction of interfaces. | Overlaps heavily with UX and UI. |
| Visual Design | Focus on aesthetics, layout, color, typography. | Subset or complementary to UI design. |
| UX Research | Systematic investigation of users and their needs. | Includes qualitative and quantitative methods. |

See [[ux-concepts]] for principles that methods help validate. See [[sources]] for books and glossaries covering these.