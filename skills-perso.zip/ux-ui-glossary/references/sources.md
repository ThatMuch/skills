---
description: "Primary sources and references for UX/UI glossaries, component catalogs, and foundational books."
connections: [components, design-systems, ux-concepts, methods]
---

# Sources

## Component & UI Pattern Catalogs
- **The Component Gallery** (component.gallery): ~60 components, definitions, synonyms, examples from ~95 design systems. Excellent for naming alignment.
- **Nielsen Norman Group – User-Interface Elements Glossary**: Comprehensive definitions of UI controls with usage and accessibility notes.
- **Material Design 2** (https://m2.material.io/): documentation de composants, états d'interaction (11 états), élévation, empty/offline states. Pages lues via leurs données publiques (rendu JavaScript). Pas de page Stepper, Rating ni Navbar dans M2 (le Stepper renvoie vers Material 1, archivé).
- **Apple Human Interface Guidelines, section Collections** (https://developer.apple.com/design/human-interface-guidelines/collections): collections, listes et tables, menus, sheets, tab bar, toolbars, rating indicator. Attention : le « stepper » Apple est un contrôle +/- pour une valeur, distinct du stepper d'étapes.
- Design system glossaries: Material Design, Carbon (IBM), Polaris (Shopify), GOV.UK, etc.

## Broader UX/UI Glossaries
- **ANODA – UX Glossary** (100+ terms): Organized by Method / Artefact / Metric / Principle / Concept. Strong coverage of design systems and states.
- **NN/g – UX Disciplines Glossary**: Clarifies boundaries between UX, UI, Interaction Design, etc.
- **UX Design Institute**: UX glossary (101 terms) + UI glossary.
- **The Glossary of Human-Computer Interaction** (IxDF / Interaction Design Foundation).

## Foundational Books
- **Don Norman – *The Design of Everyday Things***: Affordance, Signifier, Conceptual model, Mapping, Feedback, Constraints, Gulf of execution/evaluation.
- **Alan Cooper et al. – *About Face: The Essentials of Interaction Design***: Goal-directed design, personas, interaction principles.
- **Steve Krug – *Don’t Make Me Think***: Practical usability, satisficing, billboard design.
- **Brad Frost – *Atomic Design***: Component hierarchy methodology.
- **Amélie Boucher** (Eyrolles) : « Design & Interface » est une collection Eyrolles où a paru *Ergonomie web illustrée* (2010, ISBN 978-2-212-12695-2). Autres titres vérifiés : *Ergonomie web & UX Design* (4e éd. 2020, EAN 9782212137361 ; 5e éd. annoncée le 15/10/2026, ISBN 978-2-416-02370-5) et *Expérience utilisateur mobile* (2015). Un livre intitulé exactement « Design d'interface » d'Amélie Boucher n'a pas été trouvé : titre à confirmer avec Majoric. Seuls les éléments publics (éditeur, éditions, sommaire) sont utilisés ; le texte des ouvrages n'a pas été consulté.

## Other Useful References
- Usability Body of Knowledge (glossary)
- Nielsen Norman Group specialized glossaries (UI elements, UX maps, deliverables)
- Storybook Component Encyclopedia (historical)

This skill synthesizes the most relevant bridge terms from these sources. Always prefer primary sources for deep dives.