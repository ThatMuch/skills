---
description: "UX principles and concepts that directly impact UI design and front-end implementation, including accessibility and feedback."
connections: [components, design-systems, methods, sources]
---

# UX Concepts Impacting Front-End

Foundational ideas from Don Norman and others that shape how interfaces are designed and built.

| Term | Definition | Implementation Impact |
|------|------------|-----------------------|
| Affordance | Perceived properties of an object that suggest how it can be used. | Buttons should look pressable; links look clickable. |
| Signifier | Indicators of affordance (labels, icons, visual cues). | Distinguish from Affordance: Affordance is the possibility; Signifier communicates it. |
| Progressive disclosure | Revealing information or options gradually as needed. | Accordions, steppers, expandable sections. |
| Mental model | User's internal understanding of how a system works. | Align UI with expected models to reduce cognitive load. |
| Information architecture | Organization and structure of content and navigation. | Breadcrumbs, menus, search. |
| User flow | The path a user takes through an interface to complete a goal. | Guides component sequencing and states. |
| Wireframe | Low-fidelity structural representation of a screen. | Bridge to prototype and coded component. |
| Prototype | Interactive representation of a design for testing. | From low-fi to high-fi / coded. |
| Mockup | High-fidelity visual design of a screen. | Closer to final UI. |
| Accessibility (a11y) | Design and development that ensures usable by people with disabilities. | WCAG, ARIA, focus indicators, touch targets, contrast. |
| WCAG | Web Content Accessibility Guidelines — standards for accessibility. | Levels A, AA, AAA. |
| Feedback | Communication to the user about the result of an action or system state. | Success, error, loading, empty states. |
| Error prevention / recovery | Designing to avoid errors and help users recover from them. | Validation, confirmations, undo. |
| Loading / Empty / Error states | Designed views for different data or process conditions. | Skeleton, empty state illustrations, error messages. |
| Visual hierarchy | Arrangement of elements to guide attention and importance. | Typography, spacing, color, elevation. |
| Recognition over recall | Preferring visible options over requiring users to remember. | Menus, suggestions, recent items. |
| Microinteraction | Small, contained interactions that provide feedback or delight. | Button press, toggle animation, toast appearance. |

**Key Distinctions**
- Affordance vs Signifier (Norman): Affordance is what is possible; Signifier is what indicates it.
- Gulf of Execution / Evaluation: Gaps between user intent and system state (from Norman).

See [[components]] for how these appear in concrete patterns. See [[design-systems]] for states and tokens that support feedback and hierarchy. See [[sources]] for Don Norman and NN/g.