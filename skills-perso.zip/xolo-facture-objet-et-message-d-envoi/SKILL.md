---
name: 'Xolo facture : objet et message d''envoi'
description: >-
  Use this when preparing or sending an invoice in Xolo (Xolo Go has no email
  templates), to fill the 'Send to the customer' panel with the user's saved
  subject and message and apply the usual invoice settings (due date, VAT).
---
# Xolo : modèle d'email et réglages d'une facture

Xolo Go n'a pas de fonction de modèle d'email. Ce modèle est donc enregistré ici, et se colle à la main dans le panneau « Send to the customer » d'une facture.

## Objet

```
Facture prestation UX/UI
```

## Message

```
Hello,

Voici la facture concernant la prestation UX/UI
```

Le message est « Hello, », une ligne vide, puis la phrase. Pas de signature ni de variable. Adapter « UX/UI » si la prestation est différente.

## Réglages de la facture

- Échéance : toujours 1 mois après la date de la facture (par exemple facture du 30 octobre, échéance le 30 novembre). Xolo met 7 jours par défaut sur une facture dupliquée, donc corriger la date d'échéance avant d'enregistrer.
- TVA : 0 % (autoliquidation) pour Thatmuch, comme les factures précédentes.
- Date de la facture : celle du jour.
- Pour créer une nouvelle facture, dupliquer la dernière facture UX/UI du client (More actions > Duplicate) et changer le prix unitaire.

## Étapes d'envoi

1. Ouvrir la facture brouillon dans Xolo (https://app.xolo.io/selfservice/income/invoice/<id>/details).
2. Vérifier la date d'échéance (1 mois), puis cliquer sur Send pour ouvrir le panneau « Send to the customer ».
3. Remplacer l'objet et le message par le texte ci-dessus.
4. Ne cliquer sur le Send final que si l'utilisateur l'a demandé explicitement. Sinon, fermer le panneau ou cliquer sur Save draft.

Le destinataire est repris de la fiche client (supply@thatmuch.fr pour Thatmuch), et « Send me copy » est coché par défaut. Il n'y a ni champ CC ni pièce jointe : le PDF est lié par Xolo.
